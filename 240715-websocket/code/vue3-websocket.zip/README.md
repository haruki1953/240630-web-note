# 明年
  明年 前端 需求肯定会减少

  从业者淘汰

  学历

  知识分子学术派的心态

  学习和自己水平不相符的内容


  var b = 10;

  (function b () {
    b = 20;
    console.log(b);
  })();

  if (a === 1 && a === 2 && a === 3) {
    console.log(123);
  }

  Object.defineProperty   getter