const BASE_URL = 'localhost';
const WS_PORT = '8000';

export const WS_ADDRESS = `ws://${BASE_URL}:${WS_PORT}`;